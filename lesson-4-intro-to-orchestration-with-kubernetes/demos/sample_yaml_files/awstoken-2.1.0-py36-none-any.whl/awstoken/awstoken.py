#!/usr/bin/env python3
# --------------------------------------------------------------------------------
# Name: awstoken.py, awstoken
# Description: Script for AWS CLI login using Identity Provider (SAML)
# Owner: Audi Cloud Services / Group IT Cloud / Amazon Web Services
# Support: https://www.cip.audi.de/wiki/display/CLOUD/AWS+Token+usage+and+support
# Requirements: <requirements.txt>
# Version: 2.2.0
# Last update: 2010-4-15
# --------------------------------------------------------------------------------

import sys
import requests
import getpass
import configparser
import base64
import logging
import xml.etree.ElementTree as etree
import boto3
import os
import pytz
import tzlocal
import json
from bs4 import BeautifulSoup
import urllib3
from botocore.config import Config
import logging
import argparse

PROXY_LIST = {'http': 'http://127.0.0.1:3128',
              'https': 'http://127.0.0.1:3128'}
REGION = 'eu-central-1'
OUTPUT_FORMAT = 'json'
SESSION_DURATION = 3600  # Default session duration when not overridden
SSL_VERIFICATION = False

IDP_AUTH_BASE_URL = 'https://idp-sso1.audi.de'
IDP_AUTH_BASE_URL_INTERNAL = 'https://sso1.web.audi.vwg'

IDP_ENTRY_URL = IDP_AUTH_BASE_URL + \
    '/isam/sps/live-www-StrongMulti-02-audiIDP/saml20/logininitial?RequestBinding=HTTPPost&PartnerId=urn:amazon:webservices'
IDP_ENTRY_URL_INTERNAL = IDP_AUTH_BASE_URL_INTERNAL + \
    '/isam/sps/live-vwg-StrongMulti-01-audiIDP/saml20/logininitial?RequestBinding=HTTPPost&PartnerId=urn:amazon:webservices'

IDP_AUTH_FORM_SUBMIT_URL = IDP_AUTH_BASE_URL+'/pkmslogin.form'
IDP_AUTH_FORM_SUBMIT_URL_INTERNAL = IDP_AUTH_BASE_URL_INTERNAL+'/pkmslogin.form'

COOKIE_FILE = 'idpcookie.json'
FORCE_PROXY = False  # use proxy settings from the script. If environment vars are set, they will be picked up by the libs automatically
DEBUG_ACTIVE = False


if not SSL_VERIFICATION:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def clear_screen():
    if DEBUG_ACTIVE:
        return
    os.system('cls' if os.name == 'nt' else 'clear')


def load_cookielist(session, cookiefile):
    cookiefile = os.path.join(os.path.expanduser("~"), cookiefile)
    if not os.path.isfile(cookiefile):
        return False
    with open(cookiefile) as cf:
        try:
            cookielist = json.load(cf)
            for cookie in cookielist['Cookie']:
                session.cookies.set(
                    cookie['Name'], cookie['Value'], domain=cookie['Domain'])
        except ValueError:
            return False


def delete_cookielist(cookiefile):
    cookiefile = os.path.join(os.path.expanduser("~"), cookiefile)
    try:
        if os.path.exists(cookiefile):
            os.remove(cookiefile)
        else:
            logging.warn("The file "+cookiefile+" does not exist")
    except Exception as e:
        logging.debug(e)
        logging.error('Failed to remove file '+cookiefile)
        sys.exit(0)


def save_cookielist(session, cookiefile):
    cookiefile = os.path.join(os.path.expanduser("~"), cookiefile)
    cookielist = {}
    cookielist['Cookie'] = []
    for cookie in session.cookies:
        cookielist['Cookie'].append(
            {'Name': cookie.name, 'Value': cookie.value, 'Domain': cookie.domain})
    with open(cookiefile, 'w') as cf:
        json.dump(cookielist, cf, indent=4)
    os.chmod(cookiefile, 0o600)


def saml_assertion(response):
    soup = BeautifulSoup(response.content, "html.parser")
    assertion = ''
    for inputtag in soup.find_all('input'):
        if(inputtag.get('name') == 'SAMLResponse'):
            assertion = inputtag.get('value')
    return assertion


def saml_roles(assertion):
    awsroles = []
    root = etree.fromstring(base64.b64decode(assertion))
    for saml2attribute in root.iter('{urn:oasis:names:tc:SAML:2.0:assertion}Attribute'):
        if (saml2attribute.get('Name') == 'https://aws.amazon.com/SAML/Attributes/Role'):
            for saml2attributevalue in saml2attribute.iter('{urn:oasis:names:tc:SAML:2.0:assertion}AttributeValue'):
                awsroles.append(saml2attributevalue.text)
    return awsroles


def saml_role_select(awsroles):
    awsroles = sorted(list(set(awsroles)))
    for awsrole in awsroles:
        chunks = awsrole.split(',')
        if 'saml-provider' in chunks[0]:
            newawsrole = chunks[1] + ',' + chunks[0]
            index = awsroles.index(awsrole)
            awsroles.insert(index, newawsrole)
            awsroles.remove(awsrole)
    if len(awsroles) > 1:
        i = 0
        print('\nPlease choose the IAM role to assume: \n')
        for awsrole in awsroles:
            print('[' + str(i) + ']: ' + awsrole.split(',')[0])
            i += 1
        print('\nChoice: ', end='')
        selectedroleindex = input()
        try:
            if int(selectedroleindex) > (len(awsroles) - 1):
                print('You selected an invalid role index, please try again')
                sys.exit(0)
        except ValueError:
            logging.error('Invalid role selection')
            sys.exit(0)
        role_arn = awsroles[int(selectedroleindex)].split(',')[0]
        principal_arn = awsroles[int(selectedroleindex)].split(',')[1]
    else:
        role_arn = awsroles[0].split(',')[0]
        principal_arn = awsroles[0].split(',')[1]
    result = {"rolearn": role_arn, "principalarn": principal_arn}
    return result


def saml_role_assume(rolearn, principalarn, assertion):
    if FORCE_PROXY:
        proxyconfig = Config(proxies=PROXY_LIST)
    else:
        proxyconfig = Config()
    conn = boto3.client('sts', region_name=REGION,
                        use_ssl=True, verify=True, config=proxyconfig)
    token = conn.assume_role_with_saml(
        RoleArn=rolearn, PrincipalArn=principalarn, SAMLAssertion=assertion, DurationSeconds=SESSION_DURATION)
    return token


def awscli_profile(token):
    configdir = os.path.join(os.path.expanduser("~"), ".aws")
    configfile = os.path.join(os.path.expanduser("~"), ".aws", "credentials")
    accountid = token['AssumedRoleUser']['Arn'].split('/')[0].split(':')[4]
    rolename = token['AssumedRoleUser']['Arn'].split('/')[1]
    profilename = accountid + '_' + rolename + '_' + REGION
    config = configparser.RawConfigParser()
    config.read(configfile)
    if not config.has_section(profilename):
        config.add_section(profilename)
    config.set(profilename, 'output', OUTPUT_FORMAT)
    config.set(profilename, 'region', REGION)
    config.set(profilename, 'aws_access_key_id',
               token['Credentials']['AccessKeyId'])
    config.set(profilename, 'aws_secret_access_key',
               token['Credentials']['SecretAccessKey'])
    config.set(profilename, 'aws_session_token',
               token['Credentials']['SessionToken'])
    if not os.path.exists(configdir):
        os.makedirs(configdir, 0o700)
    with open(configfile, 'w+') as cf:
        config.write(cf)
    os.chmod(configfile, 0o600)
    localtimezone = tzlocal.get_localzone()
    expiration = token['Credentials']['Expiration'].replace(
        tzinfo=pytz.utc).astimezone(localtimezone)
    usermessage = (
        "\nYour temporary AWS credentials have been successfully generated.\n"
        "\naccess_key_id: "+token['Credentials']['AccessKeyId']+""
        "\nsecret_access_key: "+token['Credentials']['SecretAccessKey']+""
        "\nAWS Credentials file: {0} \nAWS Profile name: [{1}]"
        "\nAWS Token expiration: {2} (in {3} minutes)"
        "\nAWS Profile Region: {4}"
        "\nAWS CLI usage: aws <command> <subcommand> --profile {1}\n"
    ).format(configfile, profilename, expiration, SESSION_DURATION//60, REGION)
    return usermessage


def login_rsa_token():
    print('WebServices Audi Logon\n')
    loginprompt = 'IDP Login with SecurID'
    print(loginprompt + '\n' + '-' * len(loginprompt))
    print('Username: ', end=''),
    username = input()
    password = getpass.getpass(
        prompt='RSA PIN + Code (altogether without + sign): ')
    payload = {"username": username,
               "password": password, "login-form-type": "token"}
    del username
    del password
    return payload


def login_mynet():
    print('WebServices Audi Logon\n')
    loginprompt = 'IDP Login with MyNET User'
    print(loginprompt + '\n' + '-' * len(loginprompt))
    print('MyNET Username: ', end=''),
    username = input()
    password = getpass.getpass(prompt='MyNET Password (won\'t echo): ')
    payload = {"username": username,
               "password": password, "login-form-type": "pwd"}
    del username
    del password
    return payload


def read_otp():
    print('One Time Password: ', end='')
    totp = input()
    payload = {"otp": totp, "operation": "verify"}
    del totp
    return payload


def choose_login_method():
    print('Choose Login Method:')
    print('1 For MyNET, 2 for RSA Token')
    choice = input("> ")
    if choice not in ['1', '2']:
        print('Wrong Option - Exiting')
        sys.exit(1)
    return int(choice)


def get_otp_post_action(response):
    soup = BeautifulSoup(response.content, "html.parser")
    action = ''
    for formtag in soup.find_all('form'):
        if(formtag.get('name') == 'totpField'):
            action = formtag.get('action')
            break
    return action


def set_debug():
    global DEBUG_ACTIVE
    DEBUG_ACTIVE = True
    boto3.set_stream_logger('', logging.DEBUG)
    logging.basicConfig()
    logging.getLogger().setLevel(logging.DEBUG)
    requests_log = logging.getLogger("urllib3")
    requests_log.setLevel(logging.DEBUG)
    requests_log.propagate = True


def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", help="Enable debug mode",
                        action="count", default=0)
    parser.add_argument(
        "--invalidate", help="Invalidate current session", action="count", default=0)
    parser.add_argument(
        "--internal", help="Enable usage of internal URLs for IDP (.vwg)", action="count", default=0
    )
    parser.add_argument(
        "--timeout", help="Change session timeout (in minutes) - default is 60 min", type=int, action="store", default=60
    )
    parser.add_argument(
        "--region", help="Set AWS CLI profile to a specific region - defaults to eu-central-1", type=str, action="store", default="eu-central-1"
    )
    args = parser.parse_args()
    if args.debug:
        set_debug()
    if args.invalidate:
        delete_cookielist(COOKIE_FILE)
    if args.internal:
        global IDP_AUTH_BASE_URL, IDP_ENTRY_URL, IDP_AUTH_FORM_SUBMIT_URL
        IDP_AUTH_BASE_URL = IDP_AUTH_BASE_URL_INTERNAL
        IDP_ENTRY_URL = IDP_ENTRY_URL_INTERNAL
        IDP_AUTH_FORM_SUBMIT_URL = IDP_AUTH_FORM_SUBMIT_URL_INTERNAL
    global SESSION_DURATION
    SESSION_DURATION = args.timeout * 60
    global REGION
    REGION = args.region


def main():
    parse_arguments()
    try:
        session = requests.Session()
        if FORCE_PROXY:
            session.proxies = PROXY_LIST
        session.headers.update({'User-Agent': 'Mozilla/5.0'})
        #import ipdb; ipdb.set_trace()
        load_cookielist(session, COOKIE_FILE)
        response = session.get(IDP_ENTRY_URL, verify=SSL_VERIFICATION)
        assertion = saml_assertion(response)
        clear_screen()
        if (assertion == ''):
            method = choose_login_method()
            if method == 1:
                payload = login_mynet()
                response = session.post(
                    IDP_AUTH_FORM_SUBMIT_URL+'?token=Unknown', data=payload, verify=SSL_VERIFICATION)
                response = session.get(IDP_AUTH_BASE_URL + '/mga/sps/authsvc?Target=' + IDP_AUTH_BASE_URL +
                                       '/isam/sps/live-www-StrongMulti-02-audiIDP/saml20/logininitial%3FRequestBinding%3DHTTPPost%26PartnerId%3Durn%3Aamazon%3Awebservices&PolicyId=urn:ibm:security:authentication:asf:totp', verify=SSL_VERIFICATION)
                action = get_otp_post_action(response)
                otp_payload = read_otp()
                response = session.post(IDP_AUTH_BASE_URL+action, data=otp_payload,
                                        verify=SSL_VERIFICATION, cookies={'IV_JCT': '/mga'})
            else:
                payload = login_rsa_token()
                idpcookie = {'audi.ws.lastloginformtype': 'token'}
                response = session.post(
                    IDP_AUTH_FORM_SUBMIT_URL, data=payload, verify=SSL_VERIFICATION, cookies=idpcookie)
            del payload
            assertion = saml_assertion(response)
            save_cookielist(session, COOKIE_FILE)
        clear_screen()
        awsrole = saml_role_select(saml_roles(assertion))
        token = saml_role_assume(
            awsrole['rolearn'], awsrole['principalarn'], saml_assertion(response))
        clear_screen()
        print(awscli_profile(token))

    except KeyboardInterrupt:
        print('\nScript interrupted. Exiting.\n')
        sys.exit(0)

    except Exception as e:
        print(e)
        print('\nAuthorization failure. Please try again.\n')
        sys.exit(0)


if __name__ == "__main__":
    main()

# EOF
